<!DOCTYPE html>
<html>
<head>
	<title>Octocat</title>
	<style type='text/css'>
		body {
			
			color: #FFFFFF;
			background-color: #171515;
			text-align: center;
			vertical-align: middle;
		}
		b {
			color: #FDFD96;
		}
		a {
			color: #C9C9C9;
			text-decoration: none;
		}
	</style>
</head>
<body>
	<h1><b>MarkDown</b></h1>
	<p>
	<h3><b>Headers</b></h3>
	syntax: # This is a H1
	<h1>This is a H1</h1>
	syntax: ## This is a H2
	<h2>This is a H2</h2>
	syntax: ### This is a H3
	<h3>This is a H3</h3>
	<p>
	<h3><b>Link</b></h3>
	syntax: [DO9 Site](https://do9.kr/)<br>
	<a href="https://do9.kr/">DO9 Site</a>
	<p>
	<h3><b>Image</b></h3>
	syntax: ![Logo](images/DO9.png)<br>
	<img src="images/DO9.png" alt="Logo">
	<p>
</body>
</html>
