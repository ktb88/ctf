<?php
	mysql_connect("localhost", "root", "toor");
	mysql_select_db("CTF");
	# Temp flag...
	$flag = md5("Git_4nd_SQL_4dmin");
?>
